
// let sigImg = document.querySelectorAll(".signature_menu_img img"); 
let sigImg = document.querySelector(".signature_menu_img"); 
const sigTxt = document.querySelectorAll(".signature_menu_txt"); 
const createSgImg = document.createElement("img");
const menuListAll = document.querySelectorAll(".menu_list_top_info > a");
// console.log(menuListAll)


for(let x of menuListAll) {
    x.addEventListener("click",(e) => {
        e.preventDefault();

        menuListAll.forEach((ele)=>{
            // console.log(ele)
            ele.classList.remove("click_active");
        }); // forEach 

        x.classList.add("click_active");
        chgImg(e)
    }); // click event 
} // for of 

menuListAll[0].click();


function chgImg(e) {

    const btxt = e.currentTarget.innerText;
    // console.log(btxt)

    let hcode = "<ul>";
    // 이미지순번변수
    let num = 0; 

    if(subpage_menu[btxt]["이미지"].length !== 1) {
        for(let i=0; i<subpage_menu[btxt]["이미지"].length; i++) {
            hcode += `
            <li class="Signature_menu_item">
                <a href="#">
                    <figure>
                        <img src="00.data/02.imgData/SELECTO_COFFEE/${subpage_menu[btxt]["이미지"][i]}.png" alt="${subpage_menu[btxt]}이미지">
                    <figcaption>
                        <div class="signature_menu_txt">
                        ${subpage_menu[btxt]["메뉴"][i]}
                        </div>
                    </figcaption>
                </a>
            </li>
            `; 
        }
    }
        else {
            hcode += `
            <li class="Signature_menu_item">
                <a href="#">
                    <figure>
                        <img src="00.data/02.imgData/SELECTO_COFFEE/${subpage_menu[btxt]["이미지"]}.png" alt="${subpage_menu[btxt]}이미지">
                    <figcaption>
                        <div class="signature_menu_txt">
                        ${subpage_menu[btxt]["메뉴"]}
                        </div>
                    </figcaption>
                </a>
            </li>
            `; 
            
        }
        hcode += "</ul>";
            
        // console.log(hcode)
    sigImg.innerHTML = hcode; 

} // chgImg 함수() 
